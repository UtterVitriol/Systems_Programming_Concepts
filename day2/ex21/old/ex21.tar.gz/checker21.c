#include <dlfcn.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "mmu.h"
#include "solution.h"

typedef bool (*f_store_t)(mmu_t *, uint64_t, uint8_t *, size_t, bool);
typedef bool (*f_load_t)(mmu_t *, uint64_t, uint8_t *, size_t, bool);
typedef bool (*f_exec_t)(mmu_t *, uint64_t, bool);

typedef struct
{
    f_store_t store;
    f_load_t  load;
    f_exec_t  exec;
} submission_t;

static bool basic_check(submission_t *sub);
static bool wrap_check(submission_t *sub);
static bool hugepage_check(submission_t *sub);

int
main(int argc, char **argv)
{
    if (argc != 2)
    {
        fprintf(stderr, "usage: %s lib\n", argv[0]);
        return -1;
    }

    void *h_submission = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL);
    if (NULL == h_submission)
    {
        fprintf(stderr, "error: could not open library: %s\n", dlerror());
        return -2;
    }

    submission_t sub = { NULL };

    sub.store = dlsym(h_submission, "mmu_store");
    if (NULL == sub.store)
    {
        fputs("warning: not checking 'mmu_store'\n", stderr);
    }

    sub.load = dlsym(h_submission, "mmu_load");
    if (NULL == sub.load)
    {
        fputs("warning: not checking 'mmu_load'\n", stderr);
    }

    sub.exec = dlsym(h_submission, "mmu_exec");
    if (NULL == sub.exec)
    {
        fputs("warning: not checking 'mmu_exec'\n", stderr);
    }

    bool passed = true;

    passed &= basic_check(&sub);

    if (sub.store != NULL && sub.load != NULL)
    {
        passed &= wrap_check(&sub);
    }

    passed &= hugepage_check(&sub);

    return 0;
}

#define EXPECT_STORE(value, is_supervisor)                                 \
    do                                                                     \
    {                                                                      \
        if (sub->store != NULL                                             \
            && (value)                                                     \
                   != sub->store(                                          \
                       mem, v_addr, buff, sizeof(buff), (is_supervisor)))  \
        {                                                                  \
            passed = false;                                                \
            fprintf(stderr,                                                \
                    "error: store check failed: addr=%p is_supervisor=%d " \
                    "success=%d\n",                                        \
                    (void *)v_addr,                                        \
                    (is_supervisor),                                       \
                    !(value));                                             \
        }                                                                  \
    } while (0)

#define EXPECT_LOAD(value, is_supervisor)                                 \
    do                                                                    \
    {                                                                     \
        if (sub->load != NULL                                             \
            && (value)                                                    \
                   != sub->load(                                          \
                       mem, v_addr, buff, sizeof(buff), (is_supervisor))) \
        {                                                                 \
            passed = false;                                               \
            fprintf(stderr,                                               \
                    "error: load check failed: addr=%p is_supervisor=%d " \
                    "success=%d\n",                                       \
                    (void *)v_addr,                                       \
                    (is_supervisor),                                      \
                    !(value));                                            \
        }                                                                 \
    } while (0)

#define EXPECT_EXEC(value, is_supervisor)                                 \
    do                                                                    \
    {                                                                     \
        if (sub->exec != NULL                                             \
            && (value) != sub->exec(mem, v_addr, (is_supervisor)))        \
        {                                                                 \
            passed = false;                                               \
            fprintf(stderr,                                               \
                    "error: exec check failed: addr=%p is_supervisor=%d " \
                    "success=%d\n",                                       \
                    (void *)v_addr,                                       \
                    (is_supervisor),                                      \
                    !(value));                                            \
        }                                                                 \
    } while (0)

static bool
basic_check_internal(
    submission_t *sub, mmu_t *mem, size_t l4, size_t l3, size_t l2, size_t l1)
{
    size_t present       = (l4 & l3 & l2 & l1) & 1;
    size_t writable      = ((l4 & l3 & l2 & l1) >> 1) & 1;
    size_t user_viewable = ((l4 & l3 & l2 & l1) >> 2) & 1;
    size_t no_execute    = ((l4 | l3 | l2 | l1) >> 3) & 1;

    uint64_t v_addr = ((mmu_entry_t) { .vaddr = { .offset      = 0,
                                                  .table       = l1,
                                                  .directory   = l2,
                                                  .dir_pointer = l3,
                                                  .pml4        = l4,
                                                  .reserved    = 0 } })
                          .raw;
    bool    passed   = true;
    uint8_t buff[64] = { 0 };
    memset(buff, 1, sizeof(buff));

    if (!present)
    {
        EXPECT_STORE(false, false);
        EXPECT_STORE(false, true);
        EXPECT_LOAD(false, false);
        EXPECT_LOAD(false, true);
        EXPECT_EXEC(false, false);
        EXPECT_EXEC(false, true);
    }
    else
    {
        if (user_viewable)
        {
            EXPECT_STORE(writable, false);
            EXPECT_LOAD(true, false);
            EXPECT_EXEC(!no_execute, false);
        }
        else
        {
            EXPECT_STORE(false, false);
            EXPECT_LOAD(false, false);
            EXPECT_EXEC(false, false);
        }

        EXPECT_STORE(writable, true);
        EXPECT_LOAD(true, true);
        EXPECT_EXEC(!no_execute, true);
    }

    return passed;
}

static bool
basic_check(submission_t *sub)
{
    page_t *pages = calloc(sizeof(page_t), 5);
    assert(pages && "alloc failed during testing");

    pml4_t *pml4 = (pml4_t *)&pages[0];
    pdpt_t *pdpt = (pdpt_t *)&pages[1];
    pdt_t  *pdt  = (pdt_t *)&pages[2];
    pt_t   *pt   = (pt_t *)&pages[3];

    for (size_t idx = 0; idx < N_ENTRIES; idx++)
    {
        uint64_t present       = idx & 1;
        uint64_t writable      = (idx >> 1) & 1;
        uint64_t user_viewable = (idx >> 2) & 1;
        uint64_t no_execute    = (idx >> 3) & 1;

        pml4->entries[idx] = (pml4_entry_t) { .present       = present,
                                              .writable      = writable,
                                              .user_viewable = user_viewable,
                                              .page_write_through = 0,
                                              .page_cache_disable = 0,
                                              .accessed           = 0,
                                              .ignored1           = 0,
                                              .page_size          = 0,
                                              .ignored2           = 0,
                                              .restart            = 0,
                                              .pdpt_index         = 1,
                                              .ignored3           = 0,
                                              .no_execute = no_execute };

        pdpt->entries[idx] = (pdpt_entry_t) { .present       = present,
                                              .writable      = writable,
                                              .user_viewable = user_viewable,
                                              .page_write_through = 0,
                                              .page_cache_disable = 0,
                                              .accessed           = 0,
                                              .dirty              = 0,
                                              .page_size          = 0,
                                              .global             = 0,
                                              .ignored2           = 0,
                                              .restart            = 0,
                                              .pdt_index          = 2,
                                              .ignored3           = 0,
                                              .no_execute = no_execute };

        pdt->entries[idx] = (pdt_entry_t) { .present            = present,
                                            .writable           = writable,
                                            .user_viewable      = user_viewable,
                                            .page_write_through = 0,
                                            .page_cache_disable = 0,
                                            .accessed           = 0,
                                            .dirty              = 0,
                                            .page_size          = 0,
                                            .global             = 0,
                                            .ignored2           = 0,
                                            .restart            = 0,
                                            .pt_index           = 3,
                                            .ignored3           = 0,
                                            .no_execute         = no_execute };

        pt->entries[idx] = (pt_entry_t) { .present            = present,
                                          .writable           = writable,
                                          .user_viewable      = user_viewable,
                                          .page_write_through = 0,
                                          .page_cache_disable = 0,
                                          .accessed           = 0,
                                          .dirty              = 0,
                                          .page_size          = 0,
                                          .global             = 0,
                                          .ignored2           = 0,
                                          .restart            = 0,
                                          .page_index         = 4,
                                          .ignored3           = 0,
                                          .no_execute         = no_execute };
    }

    mmu_t mem = { .cr3 = 0, .page_count = 5, .pages = pages };

    bool passed = true;
    for (size_t l4 = 0; l4 < 16; l4++)
    {
        for (size_t l3 = 0; l3 < 16; l3++)
        {
            for (size_t l2 = 0; l2 < 16; l2++)
            {
                for (size_t l1 = 0; l1 < 16; l1++)
                {
                    passed &= basic_check_internal(sub, &mem, l4, l3, l2, l1);
                }
            }
        }
    }

    free(pages);

    return true;
}

static bool
wrap_check(submission_t *sub)
{
    page_t *pages = calloc(sizeof(page_t), 5);
    assert(pages && "alloc failed during testing");

    pml4_t *pml4 = (pml4_t *)&pages[0];
    pdpt_t *pdpt = (pdpt_t *)&pages[1];
    pdt_t  *pdt  = (pdt_t *)&pages[2];
    pt_t   *pt   = (pt_t *)&pages[3];

    for (size_t idx = 0; idx < N_ENTRIES; idx++)
    {
        uint64_t present       = 1;
        uint64_t writable      = 1;
        uint64_t user_viewable = (idx >> 2) & 1;
        uint64_t no_execute    = 0;

        pml4->entries[idx] = (pml4_entry_t) { .present       = present,
                                              .writable      = writable,
                                              .user_viewable = user_viewable,
                                              .page_write_through = 0,
                                              .page_cache_disable = 0,
                                              .accessed           = 0,
                                              .ignored1           = 0,
                                              .page_size          = 0,
                                              .ignored2           = 0,
                                              .restart            = 0,
                                              .pdpt_index         = 1,
                                              .ignored3           = 0,
                                              .no_execute = no_execute };

        pdpt->entries[idx] = (pdpt_entry_t) { .present       = present,
                                              .writable      = writable,
                                              .user_viewable = user_viewable,
                                              .page_write_through = 0,
                                              .page_cache_disable = 0,
                                              .accessed           = 0,
                                              .dirty              = 0,
                                              .page_size          = 0,
                                              .global             = 0,
                                              .ignored2           = 0,
                                              .restart            = 0,
                                              .pdt_index          = 2,
                                              .ignored3           = 0,
                                              .no_execute = no_execute };

        pdt->entries[idx] = (pdt_entry_t) { .present            = present,
                                            .writable           = writable,
                                            .user_viewable      = user_viewable,
                                            .page_write_through = 0,
                                            .page_cache_disable = 0,
                                            .accessed           = 0,
                                            .dirty              = 0,
                                            .page_size          = 0,
                                            .global             = 0,
                                            .ignored2           = 0,
                                            .restart            = 0,
                                            .pt_index           = 3,
                                            .ignored3           = 0,
                                            .no_execute         = no_execute };

        pt->entries[idx] = (pt_entry_t) { .present            = present,
                                          .writable           = writable,
                                          .user_viewable      = user_viewable,
                                          .page_write_through = 0,
                                          .page_cache_disable = 0,
                                          .accessed           = 0,
                                          .dirty              = 0,
                                          .page_size          = 0,
                                          .global             = 0,
                                          .ignored2           = 0,
                                          .restart            = 0,
                                          .page_index         = 4,
                                          .ignored3           = 0,
                                          .no_execute         = no_execute };
    }

    mmu_t  stack_mem = { .cr3 = 0, .page_count = 5, .pages = pages };
    mmu_t *mem       = &stack_mem;

    bool    passed    = true;
    uint8_t buff[256] = { 0 };
    memset(buff, 1, sizeof(buff));

    uint64_t v_addr = ((mmu_entry_t) { .vaddr = { .offset      = 4096 - 128,
                                                  .table       = 4,
                                                  .directory   = 4,
                                                  .dir_pointer = 4,
                                                  .pml4        = 4,
                                                  .reserved    = 0 } })
                          .raw;
    EXPECT_STORE(true, false);
    EXPECT_STORE(true, true);
    if (1 != mem->pages[4].data[1] || 1 != mem->pages[4].data[4095])
    {
        passed = false;
        fputs("error: write to user-viewable memory did not update memory\n",
              stderr);
    }

    memset(buff, 0, sizeof(buff));
    EXPECT_LOAD(true, false);
    EXPECT_LOAD(true, true);
    if (buff[0] != 1 || buff[255] != 1)
    {
        passed = false;
        fputs("error: read from user-viewable memory did not update buffer\n",
              stderr);
    }

    v_addr = ((mmu_entry_t) { .vaddr = { .offset      = 4096 - 128,
                                         .table       = 7,
                                         .directory   = 4,
                                         .dir_pointer = 4,
                                         .pml4        = 4,
                                         .reserved    = 0 } })
                 .raw;
    memset(buff, 2, sizeof(buff));
    EXPECT_STORE(false, false);
    if (1 != mem->pages[4].data[1] || 1 != mem->pages[4].data[4095])
    {
        passed = false;
        fputs("error: write to supervisor memory from userspace\n", stderr);
    }
    EXPECT_STORE(true, true);
    if (2 != mem->pages[4].data[1] || 2 != mem->pages[4].data[4095])
    {
        passed = false;
        fputs("error: write to supervisor memory did not update memory\n",
              stderr);
    }

    memset(buff, 0, sizeof(buff));
    EXPECT_LOAD(false, false);
    if (buff[0] != 0 || buff[255] != 0)
    {
        passed = false;
        fputs("error: read from supervisor memory in userspace\n", stderr);
    }
    EXPECT_LOAD(true, true);
    if (buff[0] == 0 || buff[255] == 0)
    {
        passed = false;
        fputs("error: read from supervisor memory did not update buffer\n",
              stderr);
    }

    free(pages);
    return passed;
}

static bool
hugepage_check(submission_t *sub)
{
    return true;
}