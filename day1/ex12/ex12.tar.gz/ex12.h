#ifndef EX11_H
#define EX11_H

#include <stdint.h>

uint64_t fibonacci(uint64_t n);

void get_rip(void);

void dump_regs(void);

void trace(void);

#endif